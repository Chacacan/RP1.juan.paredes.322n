
package rp.juan.paredes.pkg322n;


public class RPJuanParedes322n {


        public static void main(String[] args) {

        Torneo torneo = new Torneo();

        try {
            // 1. Agregar jugadores
            Jugador j1 = new Singlista("David Nalbandian", 3, Superficie.CEMENTO, 210);
            torneo.agregarJugador(j1);

            // Intento duplicado
            System.out.println("\nIntentando agregar jugador duplicado:");
            try {
                Jugador j1dup = new Singlista("David Nalbandian", 3, Superficie.CEMENTO, 205);
                torneo.agregarJugador(j1dup);
            } catch (JugadorDuplicadoException e) {
                System.out.println("Excepción capturada: " + e.getMessage());
            }

            Jugador j2 = new Doblista("Juan Pérez", 10, Superficie.CEMENTO, 7);
            Jugador j3 = new Juvenil("Martina Ruiz", 55, Superficie.POLVO, true);
            Jugador j4 = new Singlista("María López", 25, Superficie.CÉSPED, 190);

            torneo.agregarJugador(j2);
            torneo.agregarJugador(j3);
            torneo.agregarJugador(j4);

        } catch (JugadorDuplicadoException e) {
            e.printStackTrace();
        }

        // 2. Mostrar jugadores
        System.out.println("\n===== JUGADORES REGISTRADOS =====");
        torneo.mostrarJugadores();

        // 3. Acciones: sacar y practicar
        System.out.println("\n===== ACCIONES =====");
        torneo.sacar("David Nalbandian");
        torneo.practicaEnPareja("Juan Pérez");
        torneo.sacar("Martina Ruiz");         // Juvenil → no puede sacar
        torneo.practicaEnPareja("David Nalbandian"); // Singlista → error

        // 4. Filtrar por superficie
        System.out.println("\n===== FILTRAR POR SUPERFICIE: CEMENTO =====");
        for (Jugador j : torneo.filtrarPorSuperficie(Superficie.CEMENTO)) {
            System.out.println(j.mostrarDatos());
        }

        // 5. Resumen por tipo
        System.out.println("\n===== RESUMEN POR TIPO =====");
        torneo.resumenPorTipo();
    }
        
        
}
 
