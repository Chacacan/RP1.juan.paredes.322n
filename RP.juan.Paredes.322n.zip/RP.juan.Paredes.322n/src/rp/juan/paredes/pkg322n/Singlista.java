
package rp.juan.paredes.pkg322n;


public class Singlista extends Jugador implements Sacar {
    private double velocidadSaque;

    public Singlista(String nombre, int ranking, Superficie superficiePreferida, double velocidadSaque) {
        super(nombre, ranking, superficiePreferida);
        this.velocidadSaque = velocidadSaque;
    }

    @Override
    public void sacar() {
        System.out.println(getNombre() + " realiza un saque a " + velocidadSaque + " km/h");
    }

    @Override
    public String mostrarDatos() {
        return "Singlista: " + getNombre() + 
               ", Ranking: " + getRanking() + 
               ", Superficie preferida: " + getSuperficiePreferida() + 
               ", Velocidad de saque: " + velocidadSaque + " km/h";
    }

    @Override
    public void practicarEnPareja(Jugador pareja) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


}
