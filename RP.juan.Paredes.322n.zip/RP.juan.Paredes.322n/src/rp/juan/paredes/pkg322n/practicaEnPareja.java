
package rp.juan.paredes.pkg322n;


public interface practicaEnPareja {
    
    void practicarEnPareja(Jugador pareja);

    public void sacar();
}
