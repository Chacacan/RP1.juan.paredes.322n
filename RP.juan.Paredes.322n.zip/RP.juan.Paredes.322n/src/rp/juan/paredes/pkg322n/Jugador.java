
package rp.juan.paredes.pkg322n;

import java.util.Objects;


public abstract class Jugador implements practicaEnPareja{
    private final String nombre;
    private final int ranking;
    private final Superficie superficie;

    public Jugador(String nombre, int ranking, Superficie superficiePreferida) {
        this.nombre = nombre;
        this.ranking = ranking;
        this.superficie = superficiePreferida;
    }

    public String getNombre() {
        return nombre;
    }

    public int getRanking() {
        return ranking;
    }

    public Superficie getSuperficiePreferida() {
        return superficie;
    }

    public abstract String mostrarDatos();

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Jugador jugador = (Jugador) obj;
        return ranking == jugador.ranking && nombre.equals(jugador.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, ranking);
    }
}
