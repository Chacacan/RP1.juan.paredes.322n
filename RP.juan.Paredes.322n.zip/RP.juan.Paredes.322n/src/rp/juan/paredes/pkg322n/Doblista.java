
package rp.juan.paredes.pkg322n;


public class Doblista extends Jugador implements practicaEnPareja,Sacar {
    private int indiceCoordinacion;

    public Doblista(String nombre, int ranking, Superficie superficiePreferida, int indiceCoordinacion) {
        super(nombre, ranking, superficiePreferida);
        this.indiceCoordinacion = indiceCoordinacion;
    }

    @Override
    public void sacar() {
        System.out.println(getNombre() + " realiza un saque con coordinación nivel " + indiceCoordinacion);
    }

    @Override
    public String mostrarDatos() {
        return "Doblista: " + getNombre() + 
               ", Ranking: " + getRanking() + 
               ", Superficie preferida: " + getSuperficiePreferida() + 
               ", Índice de coordinación: " + indiceCoordinacion + "/10";
    }

    @Override
    public void practicarEnPareja(Jugador pareja) {
        System.out.println(getNombre() + " practica en pareja con coordinación " + indiceCoordinacion + "/10");
    }
}
