
package rp.juan.paredes.pkg322n;

import java.util.ArrayList;
import java.util.List;


public class Torneo {

    private List<Jugador> jugadores;

    public Torneo() {
        this.jugadores = new ArrayList<>();
    }

    public void agregarJugador(Jugador jugador) throws JugadorDuplicadoException {
        if (jugadores.contains(jugador)) {
            throw new JugadorDuplicadoException("Ya existe un jugador con el nombre " + jugador.getNombre() + 
                                              " y ranking " + jugador.getRanking());
        }
        jugadores.add(jugador);
    }

    private boolean hayJugadores(){
        return jugadores.isEmpty();
    }
    public void mostrarJugadores() {
        if (hayJugadores()) {
            System.out.println("No hay jugadores registrados en el torneo.");
            return;
        }

        System.out.println("\nJugadores registrados en el torneo:");
        for (Jugador jugador : jugadores) {
            System.out.println(jugador.mostrarDatos());
        }
    }

    public void sacar(String nombre) {
    Jugador jugador = buscarJugador(nombre);

    if (jugador == null) {
        System.out.println("El jugador " + nombre + " no está registrado en el torneo.");
        return;
    }

    if (jugador instanceof practicaEnPareja) {
        ((practicaEnPareja) jugador).sacar();
    } else {
        System.out.println("El jugador " + nombre + " no puede realizar un saque.");
        }
    }
    
    private Jugador buscarJugador(String nombre) {
        for (Jugador j : jugadores) {
            if (j.getNombre().equalsIgnoreCase(nombre)) {
                return j;
            }
        }
        return null;
    }
    
    public void practicaEnPareja(String nombre) {
        Jugador jugador = buscarJugador(nombre);

        if (jugador == null) {
            System.out.println("El jugador " + nombre + " no está registrado en el torneo.");
            return;
        }

        if (jugador instanceof practicaEnPareja) {
            ((practicaEnPareja) jugador).practicaEnPareja();
        } else {
            System.out.println("El jugador " + nombre + " no puede practicar en pareja.");
        }
    }
    
    public List<Jugador> filtrarPorSuperficie(Superficie superficie) {
    List<Jugador> resultado = new ArrayList<>();

    for (Jugador j : jugadores) {
        if (j.getSuperficiePreferida() == superficie) {
            resultado.add(j);
        }
    }

    return resultado;
}
    
    public void resumenPorTipo() {
    List<Jugador> singlistas = new ArrayList<>();
    List<Jugador> doblistas = new ArrayList<>();
    List<Jugador> juveniles = new ArrayList<>();

    for (Jugador j : jugadores) {
        if (j instanceof Singlista) {
            singlistas.add(j);
        } else if (j instanceof Doblista) {
            doblistas.add(j);
        } else if (j instanceof Juvenil) {
            juveniles.add(j);
        }
    }

    System.out.println("\n===== RESUMEN POR TIPO =====");

    System.out.println("\nSinglistas (" + singlistas.size() + "):");
    for (Jugador j : singlistas) {
        System.out.println(" - " + j.mostrarDatos());
    }

    System.out.println("\nDoblitas (" + doblistas.size() + "):");
    for (Jugador j : doblistas) {
        System.out.println(" - " + j.mostrarDatos());
    }

    System.out.println("\nJuveniles (" + juveniles.size() + "):");
    for (Jugador j : juveniles) {
        System.out.println(" - " + j.mostrarDatos());
    }
}
}

