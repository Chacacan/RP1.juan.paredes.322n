
package rp.juan.paredes.pkg322n;


public interface Sacar {
        void sacar();
}
