
package rp.juan.paredes.pkg322n;


public class Juvenil extends Jugador implements Sacar{
    private boolean tieneTutor;

    public Juvenil(String nombre, int ranking, Superficie superficiePreferida, boolean tieneTutor) {
        super(nombre, ranking, superficiePreferida);
        this.tieneTutor = tieneTutor;
    }

    @Override
    public void sacar() {
        System.out.println(getNombre() + " es juvenil y no puede realizar saques en torneos profesionales");
    }

    @Override
    public String mostrarDatos() {
        return "Juvenil: " + getNombre() + 
               ", Ranking: " + getRanking() + 
               ", Superficie preferida: " + getSuperficiePreferida() + 
               ", Tutor deportivo: " + (tieneTutor ? "Sí" : "No");
    }

    @Override
    public void practicarEnPareja(Jugador pareja) {
        System.out.println(getNombre() + (tieneTutor ? " (con tutor)" : "") + " practica en pareja con otro juvenil");
    }
}
